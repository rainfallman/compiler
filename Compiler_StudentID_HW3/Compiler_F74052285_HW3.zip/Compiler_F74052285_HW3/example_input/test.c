int a = 6.5;
int b;
float c=12.7;
void main() {
    int d=3;
    int e=7.1;
    float f=13.1;
    string aa="aab";
    d = a + 6;
    print(d);

    return;
}

