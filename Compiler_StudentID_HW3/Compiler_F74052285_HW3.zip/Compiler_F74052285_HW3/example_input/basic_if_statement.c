void main(){
	int a = 20;
    if (a == 40){
        print("a is equal to 40");
    }
    else if (a > 40){
        print("a is larger than 40");
    }
     else{
        print(666);
    }

	return;
}

