int foo(int a,float b,int c) {
   a += 6;
   
   return a;
}

void lol(int a) {
    print(a);
    print(50);
    print(13.5);
    print("aaaaaaaaaaaaaa");
	return;
}

void main(){
   int a;
   int b=6;
   b=a+4*3+5*5;
   a = foo(4);
   lol(a);
   return;
}

